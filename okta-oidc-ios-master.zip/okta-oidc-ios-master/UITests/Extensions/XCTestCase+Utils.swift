/*
 * Copyright (c) 2017-Present, Okta, Inc. and/or its affiliates. All rights reserved.
 * The Okta software accompanied by this notice is provided pursuant to the Apache License, Version 2.0 (the "License.")
 *
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0.
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *
 * See the License for the specific language governing permissions and limitations under the License.
 */

import XCTest

extension XCTestCase {
    
    /// Waits for text in the given timeout.
    /// - Parameters:
    ///   - predicate: Right hand expression is always `stringValue`. You should pass only predicate operator and left hand expression. For instance, `CONTAINS 'Error'`, `!= 'Token'` etc.
    ///   - object: An object against which the predicate is evaluated.
    ///   - timeout: Waiting time before triggering a test failure.
    func waitForText(predicate: String, object: XCUIElement, timeout: TimeInterval) {
        let expectation = XCTNSPredicateExpectation(predicate: .init(format: "%K \(predicate)", #keyPath(XCUIElement.stringValue)), object: object)
        
        wait(for: [expectation], timeout: timeout)
    }
}
